@include('layouts.CalorixLayout')
<body>
<main class="max-w-5xl mx-auto px-6 py-12">
    {{ $slot ?? '' }}
</main>
</body>

