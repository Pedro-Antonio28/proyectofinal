<!DOCTYPE html>
<html lang="es">
<head>
    <title>Prueba</title>
</head>
<body>
{{ $slot }}
</body>
</html>
