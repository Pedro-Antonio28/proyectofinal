<p>Hola {{ $post->user->name }},</p>
<p>El usuario <strong>{{ $user->name }}</strong> ha añadido tu dieta "<strong>{{ $post->title }}</strong>" a su perfil.</p>
<p>¡Sigue compartiendo contenido saludable!</p>
