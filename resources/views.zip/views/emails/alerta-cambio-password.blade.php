<p>Hola {{ $user->name }},</p>

<p>Te informamos que tu contraseña fue modificada correctamente.</p>

<p>Si no fuiste tú, por favor restablece tu contraseña cuanto antes o contacta con soporte.</p>

<p>Saludos,<br>El equipo de Nutrición</p>
